<!DOCTYPE html>
<html class=''>

<head>
    <link href="{{url('public/css/bootstrap.css')}}" rel="stylesheet" id="bootstrap-css">
    <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,600' rel='stylesheet' type='text/css'>
    <link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.2/css/font-awesome.min.css'>
    <link rel="stylesheet" href="{{url('public/css/custom.css')}}">
</head>

<body>
    <div id="frame">
        <div id="sidepanel">
            <div id="profile">
                <div class="wrap">
                    <img id="profile-img" src="http://emilcarlsson.se/assets/mikeross.png" class="online" alt="" />
                    <p>{{Auth::User()->name}}</p>
                </div>
            </div>
            <div id="contacts">
                <ul>
                    @foreach ($friends as $key => $value)

                    <li class="contact" id="contact_{{$value->id}}" onclick="getUserChat('{{$value->id}}','{{$value->name}}')">
                        <div class="wrap">                            
                            <span class="contact-status {{($value->is_online==1)?'online':'away'}} online_{{$value->id}}"></span>
                            <img src="https://picsum.photos/50/50/?random{{$key}}" alt="" />
                            <div class="meta">
                            <label id="unread_off_{{$value->id}}" title="{{$value->unread_messages}} unread messages" class="badge badge-success pull-right">{{($value->unread_messages>0)?$value->unread_messages:''}}</label>
                            <p class="name" id="name_{{$value->id}}">{{$value->name}}</p>
                            <p class="preview">You just got LITT up, Mike.</p>                            
                            </div>                            
                        </div>
                    </li>

                    @endforeach
                </ul>
            </div>
        </div>
        <div class="content">
            <div class="contact-profile">
                <img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />
                <p class="receiver_name">Harvey Specter</p>
                <p class="text-info typing-indicator" style="margin-left:20px;"></p>
            </div>
            <div class="messages">
                <ul class="message-ul">
                    <li class="sent">
                        <img src="http://emilcarlsson.se/assets/mikeross.png" alt="" />
                        <p>How the hell am I supposed to get a jury to believe you when I am not even sure that I do?!</p>
                    </li>
                    <li class="replies">
                        <img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />
                        <p>When you're backed against the wall, break the god damn thing down.</p>
                    </li>
                </ul>
            </div>
            <div class="message-input">
                <div class="wrap">
                    <form id="chatForm">
                        <input id="m" type="text" placeholder="Write your message..." />
                        <i class="fa fa-paperclip attachment" aria-hidden="true"></i>
                        <button onclick="$('form#chatForm').submit();" class="submit"><i class="fa fa-paper-plane"
                                aria-hidden="true"></i></button>
                    </form>
                </div>
            </div>
        </div>
        <div class="content-2">
            <h1 class="text-center" style="font-size:2em;margin-top:2em">Please Choose a Contact first</h1>
        </div>
    </div>

    <script src="{{url('public/js/jquery.js')}}"></script>
    <script src="{{url('public/js/bootstrap.js')}}"></script>
    <script src="{{url('public/js/moment.min.js')}}"></script>
    <script src="{{url('public/js/socket.io-1.2.0.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/push.js/1.0.5/push.js"></script>
    <script>
        var host = location.host;
        var other_user_id = null;
        var userId = "{{Auth::id()}}";
        var username = "{{Auth::User()->name}}";
        var socket = io.connect('http://192.168.0.181:4200', {
            query: "user_id=" + userId + ""
        });
        socket.on('connect', function () {
            //console.log('connected');
            socket.on('send_message', function (data) {
                //console.log(data);
                var dateTime = new Date(data.user_time);
                if (data.user_id == other_user_id) {
                    //$(".typing-indicator").html('');
                    if (data.user_id == userId) {
                        var skey = "replies";
                    } else {
                        var skey = "sent";
                    }
                    var string = '<li class="' + skey +
                        '"><img src="http://emilcarlsson.se/assets/mikeross.png" alt="" /><p>' + data.message +
                        '</p></li>';
                    $(".message-ul").append(string);
                    $('.messages').scrollTop($('.messages')[0].scrollHeight - $('.messages')[0].clientHeight);
                }else{
                    //console.log(data);
                    var prev = $("#unread_off_"+data.user_id).html();
                    if(prev==''){
                        var count = 1;
                    }else{
                        var count =  parseInt(prev)+1;
                    }
                    $("#unread_off_"+data.user_id).html(count);
                    // $.ajax({
                    //     type:"post",
                    //     url:site_url+'/update-message-status',
                    //     data:{from:data.user_id,to:data.other_id},
                    //     success:function(){

                    //     }
                    // })
                }
            });
            socket.on('user-typing', function (data) {
                //console.log(data);
                if (data.userId == other_user_id) {
                    $(".typing-indicator").html(data.username + ' is typing...');
                }
            });

            socket.on('user-stop-typing', function (data) {
                //console.log("Someone is typing");
                if (data.userId == other_user_id) {
                    $(".typing-indicator").html('');
                }
            });

        });
        if (host == "localhost" || host == "192.168.0.181") {
            site_url = location.protocol + '//' + location.host + '/Laravel/Socket-chat';
        } else {
            site_url = location.protocol + '//' + location.host
        }

        function getUserChat(id, name) {
            other_user_id = id;
            $(".content-2").hide();
            $(".content").show();
            $(".receiver_name").html(name);
            $(".contact").removeClass('active');
            $("#contact_" + id).addClass('active');
            $("#unread_off_"+id).text('');
            $(".typing-indicator").html('');
            $.ajax({
                type: "get",
                url: site_url + '/get-user-chat/' + id,
                success: function (response) {
                    $(".message-ul").html('');
                    if (response.length > 0) {
                        $.each(response, function (key, value) {
                            if (value.to == other_user_id) {
                                var skey = "replies";
                            } else {
                                var skey = "sent";
                            }
                            var string = '<li class="' + skey +
                                '"><img src="http://emilcarlsson.se/assets/mikeross.png" alt="" /><p>' +
                                value.text + '</p></li>';
                            $(".message-ul").append(string);
                        });
                        $('.messages').scrollTop($('.messages')[0].scrollHeight - $('.messages')[0].clientHeight);
                    } else {
                        //$(".message-ul").append("<p class='text-center no-text'>No message found.</p>");
                    }
                }
            })
        }

        $(function () {
            $('#chatForm').submit(function (event) {
                if ($.trim($('#m').val()) == "") {
                    $('#m').val('');
                    $('#m').focus();
                    return false;
                }
                var log_obj = {
                    "user_id": userId,
                    "other_id": other_user_id,
                    "message": $('#m').val(),
                    "type": "1",
                };

                socket.emit('send_message', log_obj);
                var str =
                    '<li class="replies"><img src="http://emilcarlsson.se/assets/mikeross.png" alt="" /><p>' +
                    log_obj.message + '</p></li>';
                $(".message-ul").append(str);
                $('.messages').scrollTop($('.messages')[0].scrollHeight - $('.messages')[0].clientHeight);
                $('#m').val('');
                event.preventDefault();
            });

            $("#m").keyup(function () {
                socket.emit('user-typing', {
                    other_user_id: other_user_id,
                    username: username,
                    userId: userId
                });
            })

            $("#m").focusout(function () {
                socket.emit('user-stop-typing', {
                    other_user_id: other_user_id,
                    username: username,
                    userId: userId
                });
            });

            socket.on('off_line', function (id) {
                $(".online_" + id).removeClass("online");
                $(".online_" + id).addClass("away");
                Push.create('Chatkit', {
                    body: $("#name_"+id).text()+' is offline',
                    icon: 'http://placeimg.com/60/60', 
                    requireInteraction:true, 
                    timeout: 5000,
                    onClick: function () {
                        window.focus();
                        this.close();
                    }
                });
            });

            socket.on('on_line', function (id) {
                $(".online_" + id).removeClass("away");
                $(".online_" + id).addClass("online");
                if(id != userId){
                    Push.create('Chatkit', {
                        body: $("#name_"+id).text()+' is online',
                        icon: 'http://placeimg.com/60/60', 
                        requireInteraction:true, 
                        timeout: 5000,
                        onClick: function () {
                            window.focus();
                            this.close();
                        }
                    });
                }
            });

        });

        setInterval(function(){
            $(".typing-indicator").html('');
        }, 3000);
    </script>
</body>

</html>