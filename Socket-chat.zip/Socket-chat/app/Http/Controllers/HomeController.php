<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Message;
use Auth;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $friends = User::where('id','!=',Auth::id())->get();
        if($friends){
            foreach ($friends as $key => $value) {
                $friend_id = $value->id;
                $user_id = Auth::id();
                $unread_messages = $messages = Message::where(['from'=>$friend_id,'to'=>$user_id,'status'=>0])->count();
                $friends[$key]->unread_messages = $unread_messages;
            }
        }
        return view('home',compact('friends'));
    }

    public function logout(){
        Auth::logout();
        return redirect('/');
    }

    public function get_user_chat(Request $request,$id){
        $auth_id = Auth::id();
        if($request->ajax()){
            Message::where(['from'=>$id,'to'=>$auth_id,'status'=>0])->update(['status'=>1]);
            $messages = Message::where(function($q) use($id,$auth_id){
                $q->where('from',$id);
                $q->where('to',$auth_id);
            })->orWhere(function($q) use($id,$auth_id){
                $q->where('from',$auth_id);
                $q->where('to',$id);
            })->get();
            return response()->json($messages);
        }else{  
            die('Access Denied');
        }    
    }

    public function update_message_status(Request $request){
        Message::where(['from'=>$request->get('from'),'to'=>$request->get('to')])->first()->update(['status'=>0]);
    }

}
