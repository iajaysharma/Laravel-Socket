@extends('layouts.initail')

@section('content')


@include('includes.topbar')

  <link rel="stylesheet" type="text/css" href="{{url('public/emojipicker/css/jquery.emojipicker.css')}}">
  <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
  <script type="text/javascript" src="{{url('public/emojipicker/js/jquery.emojipicker.js')}}"></script>

  <!-- Emoji Data -->
  <link rel="stylesheet" type="text/css" href="{{url('public/emojipicker/css/jquery.emojipicker.a.css')}}">
  <script type="text/javascript" src="{{url('public/emojipicker/js/jquery.emojis.js')}}"></script>

<script type="text/javascript">
    $(document).ready(function(e) {
      $('#m').emojiPicker({
        position: 'left'
      });

      // keyup event is fired
      $(".emojiable-question, .emojiable-option").on("keyup", function () {
        //console.log("emoji added, input val() is: " + $(this).val());
      });

    });
  </script>

<div class="dashboard-main">
    <div class="container">
        <h1 class="main-heading">Inbox</h1>
        <div class="row m-bottom30 m-top20">
            <div class="col-sm-4 col-md-4 p-right0 xs-t">
               <aside class="chatmans clearfix">
                    <div class="header-chat clearfix">
                        <select class="form-control">
                            <option>
                                All Conversation
                            </option>
                        </select>
                        <i class="fa fa-search pull-right"></i>
                    </div>
                    @if(count($friendlist)>0)
                    @foreach($friendlist as $key => $friend)
                    <?php  
                        $profileImage = !empty($friend["profile_picture"])?url($friend["profile_picture"]):url("public/front/img/demo_user.png");
                            if($key==0){
                                $other['id']          = $friend["id"];
                                $other['image']       = !empty($friend["profile_picture"])?url($friend["profile_picture"]):url("public/front/img/demo_user.png");
                                $other['full_name']   = $friend["full_name"];
                            }
                            $user['id']          = Auth::user()->id;
                            $user['image']       = !empty(Auth::user()->profile_picture)?url(Auth::user()->profile_picture):url("public/front/img/demo_user.png");
                            $user['full_name']   = Auth::user()->full_name;
                        ?>
                       <div  class="listing-chater {{($key==0)?'active':''}}" other-id="{{$friend['id']}}" other-name="{{$friend['full_name']}}" other-image="{{$profileImage}}">
                           <a href="javascript:void(0);">
                               <img  src="{{$profileImage}}">
                               <hgroup>
                                   <h2>{{$friend["full_name"]}} 
                                    <span class="pull-right">{{date('d M')}}</span>
                                   </h2>
                                   <p>...</p>
                               </hgroup>
                           </a>
                       </div>
                   @endforeach
                   @endif
               </aside>
            </div>
            <span id="other-data" other-id="{{@$other['id']}}" other-name="{{@$other['full_name']}}" other-image="{{@$other['image']}}" >
            <div class="col-md-8 col-sm-8 p-left0 bg-t">
                <aside class="right-chat">
                     <div class="chat-header">
                        <h1>
                            <img id="current-chat-img"  src="{{url('public/front/images/active.png')}}" >
                            <span id="current-chat-name">{{@$other['full_name']}}</span>
                         </h1>
                        <p>Last seen 17 min ago     <span>|</span>   Local time  10:27 AM</p>
                    </div>
                   <div class="cheters" id="messages">
                   @if(count($chats)>0)
                   @foreach($chats as $chat)
                        @if($chat['user_id']!==$user['id'])
                            @if($chat['type']=="TEXT")
                                <div class="sender clearfix">
                                    <img src="{{url($chat['user_image'])}}" class="senderimg">
                                    <hgroup>
                                        <h3>{{$chat['user_name']}} <span>{{date('h:i A | d M ',strtotime($chat['user_time']))}}</span> </h3>
                                        <p class="chatmssg">{{$chat['message']}}</p>
                                    </hgroup>
                                </div>
                            @else
                                <div class="sender clearfix">
                                    <img src="{{url($chat['user_image'])}}" class="senderimg">
                                    <hgroup>
                                        <h3>{{$chat['user_name']}} <span>{{date('h:i A | d M ',strtotime($chat['user_time']))}}</span> </h3>
                                        <img class="chatmssg" src="{{url('chat/'.$chat['message'])}}" />
                                    </hgroup>
                                </div>
                            @endif
                        @else    
                            @if($chat['type']=="TEXT")
                                <div class="recever clearfix">
                                    <img src="{{url($chat['user_image'])}}" class="senderimg">
                                    <hgroup>
                                        <h3>{{$chat['user_name']}} <span>{{date('h:i A | d M ',strtotime($chat['user_time']))}}</span> </h3>
                                        <p class="chatmssg">{{$chat['message']}}</p>
                                    </hgroup>
                                </div>
                            @else
                                <div class="recever clearfix">
                                    <img src="{{url($chat['user_image'])}}" class="senderimg">
                                    <hgroup>
                                        <h3>{{$chat['user_name']}} <span>{{date('h:i A | d M ',strtotime($chat['user_time']))}}</span> </h3>
                                        <img class="chatmssg" src="{{url('chat/'.$chat['message'])}}" />
                                    </hgroup>
                                </div>
                            @endif    
                        @endif
                    @endforeach
                    @endif
                    </div>
                    <div class="from-group chetform">
                    <form id="chatForm" enctype="multipart/form-data" action="">
                        <p>
                            <span class="upload-file ">
                                <input type="file" id="imageFile" name="image_upload" accept="image/*">
                                <i class="fa fa-paperclip"></i>
                            </span>
                        </p>
                        <input type="hidden" name="type" value="TEXT">
                        <div class="input-group">
                        
                            <input id="m" class="emojiable-option form-control" type="text"  placeholder="Type your message">
                            <a href="javascript:void(0)" onclick="$('form#chatForm').submit();" class="input-group-addon btn-default">
                                Send
                            </a>
                        </div>
                    </form>

                    </div>
                </aside>
            </div>
        </div>
    </div>
</div>

<script src="{{url('public/front/js/moment.min.js')}}"></script>
<script src="{{url('public/front/js/socket.io-1.2.0.js')}}"></script>
<script>
    var userId    = {{@$user['id']}}; 
    var userName  = "{{@$user['full_name']}}"; 
    var userImage = "{{@$user['image']}}"; 
    var other     =  $("#other-data");
    var otherId   = other.attr("other-id"); 
    var otherName = other.attr("other-name"); 
    var otherImage= other.attr("other-image");
    //alert(userId);
    var socket = io.connect('http://192.168.0.181:4200',{query:"user_id="+userId+""});
    socket.on('connect', function () {
        console.log('connected');
        socket.on('send_message', function(data){
            console.log(data);
          //console.log(userId +"=="+ data.user_id);
          var dateTime = new Date(data.user_time);
          if(userId == data.user_id){
            if(data.type=="TEXT"){
                $('#messages').append('<div class="recever clearfix"><img src="'+data.user_image+'" class="senderimg"><hgroup><h3>'+data.user_name+'<span>'+moment(dateTime).format("HH:mm A | MMM DD")+'</span> </h3><p class="chatmssg">'+data.message+'</p></hgroup></div>') ;
            }else{
                $('#messages').append('<div class="recever clearfix"><img src="'+data.user_image+'" class="senderimg"><hgroup><h3>'+data.user_name+'<span>'+moment(dateTime).format("HH:mm A | MMM DD")+'</span> </h3><img class="chatmssg" src="'+data.message+'"/></hgroup></div>') ;
            }
          }else{
            if(data.type=="TEXT"){
                $('#messages').append('<div class="sender clearfix"><img src="'+data.user_image+'" class="senderimg"><hgroup><h3>'+data.user_name+'<span>'+moment(dateTime).format("HH:mm A | MMM DD")+'</span> </h3><p class="chatmssg">'+data.message+'</p></hgroup></div>');                
            }else{
                $('#messages').append('<div class="recever clearfix"><img src="'+data.user_image+'" class="senderimg"><hgroup><h3>'+data.user_name+'<span>'+moment(dateTime).format("HH:mm A | MMM DD")+'</span> </h3><img class="chatmssg" src="'+data.message+'"/</hgroup></div>') ;
            }

          }
          $("#messages").animate({ scrollTop: $("#messages").prop('scrollHeight') - $("#messages").position().top }, "slow");
        });
/*
        socket.on('disconnect',function(){
            

        });*/
    });

      $('#imageFile').on('change', function(e){
            var file = e.originalEvent.target.files[0],
                  reader = new FileReader();
            reader.onload = function(evt){
            var log_obj =
                    {
                        "user_id"       : userId,
                        "user_name"     : userName,
                        "user_image"    : userImage,
                        "other_id"      : other.attr('other-id'),
                        "other_name"    : other.attr('other-name'),
                        "other_image"   : other.attr('other-image'),
                        "message"       : evt.target.result,
                        "type"          : "IMAGE",
                    };
                    console.log(log_obj);
                socket.emit('send_message', log_obj);    
              // send a custom socket message to server
              ///socket.emit('user image', jsonObject);
          };
          reader.readAsDataURL(file);
      });


    $(function () {
      $('#chatForm').submit(function(event){
        if($.trim($('#m').val())==""){
          $('#m').val('');
          $('#m').focus();
          return false;
        }
        var log_obj =
                {
                    "user_id"       : userId,
                    "user_name"     : userName,
                    "user_image"    : userImage,
                    "other_id"      : other.attr('other-id'),
                    "other_name"    : other.attr('other-name'),
                    "other_image"   : other.attr('other-image'),
                    "message"       : $('#m').val(),
                    "type"          : "TEXT",
                };

        socket.emit('send_message', log_obj);
        $('#m').val('');
        event.preventDefault();
      });

    });

    // Get previous chat data .
    $(".listing-chater").click(function(){

        // Replace chat header data.
        $("#current-chat-name").html($(this).attr('other-name'));

        // Set other data for chat communication.
        other.attr('other-id',$(this).attr('other-id'));
        other.attr('other-name',$(this).attr('other-name'));
        other.attr('other-image',$(this).attr('other-image'));
        //loader show
        $('.loading').show();
        // Otp generate verificaiton ajax run 
        $.ajax({
            type : "POST",
            url: baseUrl + '/get-chat',
            dataType : "JSON",
            //async:false,
            data:{"_token": "{{ csrf_token() }}",'other_id':$(this).attr('other-id')},
            success : function(response){
                console.log(response);
                var chats = "";
                $.each(response.data, function( index, chat ) {
                    var dateTime = new Date(chat.user_time);
                    if(userId == chat.user_id){
                        if(chat.type=="TEXT"){
                            chats +='<div class="recever clearfix"><img src="'+chat.user_image+'" class="senderimg"><hgroup><h3>'+chat.user_name+'<span>'+moment(dateTime).format("HH:mm A | MMM DD")+'</span> </h3><p class="chatmssg">'+chat.message+'</p></hgroup></div>';
                        }else{
                            chats +='<div class="recever clearfix"><img src="'+chat.user_image+'" class="senderimg"><hgroup><h3>'+chat.user_name+'<span>'+moment(dateTime).format("HH:mm A | MMM DD")+'</span> </h3><img class="chatmssg" src="chat/'+chat.message+'" /></hgroup></div>';
                        }
                    }else{
                        if(chat.type=="TEXT"){
                            chats +='<div class="sender clearfix"><img src="'+chat.user_image+'" class="senderimg"><hgroup><h3>'+chat.user_name+'<span>'+moment(dateTime).format("HH:mm A | MMM DD")+'</span> </h3><p class="chatmssg">'+chat.message+'</p></hgroup></div>';
                        }else{
                            chats +='<div class="sender clearfix"><img src="'+chat.user_image+'" class="senderimg"><hgroup><h3>'+chat.user_name+'<span>'+moment(dateTime).format("HH:mm A | MMM DD")+'</span> </h3><img class="chatmssg" src="chat/'+chat.message+'" /></hgroup></div>';
                        }                        
                    }
                });
                $("#messages").html(chats);
                  $("#messages").animate({ scrollTop: $("#messages").prop('scrollHeight') - $("#messages").position().top }, "slow");

                $('.loading').hide();
            },
            error: function (request, status, error) {
                //loader hide
                $('.loading').hide();
                return false;
            }
        });
    })
</script>

@endsection
