var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var port = process.env.PORT || 4200;
var moment = require('moment');
var fs = require('fs');
var Sync = require('sync');
var sockets = {};

/*mysql create connection*/
var db = require('./config/db');

app.get('/', function (req, res) {
	res.sendFile(__dirname + '/index.html');
});

app.get('/second', function (req, res) {
	res.sendFile(__dirname + '/second.html');
});

io.on('connection', function (socket) {

	sockets[socket.handshake.query.user_id] = socket;

	var queryData = 'update users SET `is_online` = 1 where id = ' + socket.handshake.query.user_id;
	db.query(queryData, function (error, result, fields) {
		socket.broadcast.emit('on_line', socket.handshake.query.user_id);
	});


	// This event use for send message.
	socket.on('send_message', function (data) {
		data.user_time = moment(new Date()).format('YYYY-MM-DD h:mm:ss');
		var message = data.message;
		var msgType = data.type;
		var messageId = "";

		// Sync use for sync process .
		Sync(function () {
			var chat = {
				from: data.user_id,
				to: data.other_id,
				text: message,
				type: data.type
			};
			db.query('INSERT INTO messages SET ?', chat, function (error, results, fields) {
				console.log('Chat Data Inserted : ', chat);
				//messageId = results.insertId;

				// This code use for image upload
				if (msgType == "IMAGE") {
					var img = image;
					var ext = img.split(';')[0].match(/jpeg|png|gif/)[0];
					var dir = 'uploads' + '/';
					if (!fs.existsSync(dir)) {
						fs.mkdirSync(dir);
					}
					var imgName = dir + Date.now() + '.' + ext
					var data = img.replace(/^data:image\/\w+;base64,/, "");
					var buf = new Buffer(data, 'base64');
					var imgs = fs.writeFile(imgName, buf, function (err) {
						if (err) console.log(err);

					});
					imgUrl = imgName;
					console.log(imgUrl);
					var queryData = 'update chat SET `message` = "' + imgName + '" where id = ' + results.insertId;
					console.log(queryData);
					db.query(queryData, function (error, result, fields) {
						console.log('Chat Image Uploaded successfully. : ', result);
					});
				}
			}, function (err, result) { // <-- standard callback 
				if (error) throw error;
				//console.log(data);
			});

			if (sockets[data.other_id] != undefined) {
				sockets[data.other_id].emit('send_message', data);
			}

		});

	});

	// This event use for off line user      
	socket.on('disconnect', function () {
		var index = socket.handshake.query.user_id;
		socket.broadcast.emit('off_line', index);
		var queryData = 'update users SET `is_online` = 0 where id = ' + socket.handshake.query.user_id;
		db.query(queryData, function (error, result, fields) {
			//console.log('User offline successfully. : ' + socket.handshake.query.user_id);
		});
	});

	socket.on('user-typing', function (data) {
		//console.log(data);
		if (sockets[data.other_user_id] != undefined) {
			sockets[data.other_user_id].emit('user-typing', data);
		}
	});

	socket.on('user-stop-typing', function (data) {
		//console.log(data);
		if (sockets[data.other_user_id] != undefined) {
			sockets[data.other_user_id].emit('user-stop-typing', data);
		}
	});

});

http.listen(port, function () {
	console.log('listening on *:' + port);
});