var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var port = process.env.PORT || 4201;
var moment = require('moment');
var sockets = {};
var restaurants = {};

/*mysql create connection*/
var db = require('./config/db');

app.get('/', function(req, res){
  res.sendFile(__dirname + '/index.html');
});

app.get('/second', function(req, res) {
    res.sendFile(__dirname + '/second.html');
});

io.on('connection', function(socket){

    //sockets[socket.handshake.query.user_id] = socket;
    var user_type = socket.handshake.query.user_type;

    if (user_type == "user") {
        sockets[socket.handshake.query.user_id] = socket;
        console.log("user connect : ", socket.handshake.query);
    } else {
        restaurants[socket.handshake.query.user_id] = socket;
        console.log("restaurants connect : ", socket.handshake.query);
    } 

	socket.on('send_message', function(data){
		console.log(data);
		data.user_time = moment(new Date()).format('YYYY-MM-DD h:mm:ss');
		sockets[data.user_id].emit('send_message', data);
		sockets[data.other_id].emit('send_message', data);
		var groupId = (data.user_id>data.other_id)?data.user_id+""+data.other_id:data.other_id+""+data.user_id;
		var chat  = {	
						group_id	: groupId,
						user_id		: data.user_id,	
						user_name	: 'lokesh',
						user_image	: 'lokesh',
						other_name	: 'mahaveer',
						other_image	: 'mahaveer',
						other_id	: data.other_id,
						message		: data.message,
						user_time	: moment(new Date()).format('YYYY-MM-DD h:mm:ss')
					};
		db.query('INSERT INTO chat SET ?', chat, function (error, results, fields) {
		  if (error) throw error;
		  console.log('The solution is: ', results);
		});
		//io.emit('chat message', msg);
	});
});


http.listen(port, function(){
  console.log('listening on *:' + port);
});
